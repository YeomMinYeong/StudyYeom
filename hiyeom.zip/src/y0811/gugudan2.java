package y0811;

public class gugudan2 {

	public static void main(String[] args) {
		// 구구단 기본형
		int a,b;
		for(a=2; a<10; a++) {
			for(b=1; b<10; b++) {


			    System.out.println(a+"X"+b+"="+a*b+"\t");

			   }
			  }
			 }
			}
//System.out.println(+a+"*"+b+"="+a*b); 